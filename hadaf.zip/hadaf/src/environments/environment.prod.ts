export const environment = {
  production: true,
  BASE_URL: 'https://jsonplaceholder.typicode.com/'
};
